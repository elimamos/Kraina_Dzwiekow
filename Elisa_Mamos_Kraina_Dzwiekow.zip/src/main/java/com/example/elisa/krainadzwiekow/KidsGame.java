/*
* Elisa Mamos IBM sem. V IwM ETI
* 155305
* 2016/17
* */
package com.example.elisa.krainadzwiekow;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 *
 * Klasa zajmująca się obsługą gry dla dzieci, wraz z wszystkimi jej przypadkami.
 *
 * Rozgrywką nazywać będziemy pojedyncze wykonanie metod zawartych w tej klasie.
 * Na grę składa się dowolna liczba rozgrywek. Gra kończy się w momencie wywołania metody backToMenu(View);
 *
 * @author Elisa Mamos
 */
public class KidsGame extends AppCompatActivity {
    /**
     * {@link AdultGame#imgNamesList}
     */
    List<String> imgNamesSelected;
    /**
     * Lista ID obrazów wykorzystywanych podczas gry w zasobach gry.
     */

    List<Integer> imgIdNumber;
    /**
     * {@link AdultGame#soundList}
     */
    private List<GameItem> soundList = new ArrayList<GameItem>();
    /**
     * {@link AdultGame#randomGenerator}
     */
    private Random randomGenerator;
    /**
     * {@link AdultGame#mp
     */
    MediaPlayer mp;
    /**
     * {@link AdultGame#playedSoundIndex}
     */
    int playedSoundIndex;
    /**
     * {@link AdultGame#points}
     */
    int points=2;
    /**
     * {@link AdultGame#sum}
     */
    int sum;

    /**
     *  /**
     * Klasa zajmująca się załadowaniem interfejsu gry, przypisaniem do zmiennej "sum" sumy punktów uzyskanej w poprzedniej rozgrywce,
     *załadowaniem dźwięków do listy obiektów typu GameItem, wylosowaniem
     * losowego indeksu dźwięku,który zostanie odtworzony, wylosowaniem i ustawieniem tła przycisków. Odtworzony zostaje też dźwięk
     * w celu rozpoczęcia rozgrywki. Dzieje się to z wymuszonym opóźnieniem, gdyż aplikacja potrzebuje czasu do pełnego załadowania interfejsu
     * @param savedInstanceState
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_kids_game);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);


        Button bckgrnd1=(Button)findViewById(R.id.background1);
        Button bckgrnd2=(Button)findViewById(R.id.background2);
        Button bckgrnd3=(Button)findViewById(R.id.background3);
        bckgrnd1.setVisibility(View.INVISIBLE);
        bckgrnd2.setVisibility(View.INVISIBLE);
        bckgrnd3.setVisibility(View.INVISIBLE);

        SharedPreferences settings = getSharedPreferences("SUMA", 0);
        sum = settings.getInt("Suma",0);

        loadSounds();
        getSoundId();
        setButtonBackgroundsRand();



        Runnable task = new Runnable() {
            public void run() {
                playSound();

            }
        };

        Handler handler = new Handler();
        handler.postDelayed(task, 1000);
        TextView txt = (TextView)findViewById(R.id.sum);
        txt.setText(Integer.toString( sum));


    }

    /**
     * {@link AdultGame#getSoundId()}
     */

    private void getSoundId(){
        randomGenerator = new Random();
        playedSoundIndex = randomGenerator.nextInt(soundList.size());


    }

    /**
     * Dodaje nazwy użytych grafik do listy. {@see imgNameSelected}
     */
    private  void getNameOfImg(){
       String name1 =getResources().getResourceEntryName(imgIdNumber.get(0));
        String name2 =getResources().getResourceEntryName(imgIdNumber.get(1));
        String name3 =getResources().getResourceEntryName(imgIdNumber.get(2));

        imgNamesSelected=new ArrayList<String>();
        imgNamesSelected.add(name1);
        imgNamesSelected.add(name2);
        imgNamesSelected.add(name3);

    }


    /**{@link AdultGame#playSound()}
     *
     */
    public void playSound() {


        mp = MediaPlayer.create(this, this.soundList.get(playedSoundIndex).getResId());
        mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            public void onCompletion(MediaPlayer mp) {

                mp.reset();
                mp.release();
                mp = null;
            }

        });
        try {
            mp.start();
            Thread.sleep(2000);
            mp.stop();

        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    /**
     * {@link AdultGame#loadSounds()}
     */
    private void loadSounds() {
        soundList.add(new GameItem("cat", R.raw.cat));
        soundList.add(new GameItem("cow", R.raw.cow));
        soundList.add(new GameItem("dog", R.raw.dog));
        soundList.add(new GameItem("horse", R.raw.horse));
        soundList.add(new GameItem("pig", R.raw.pig));
        soundList.add(new GameItem("lion", R.raw.lion));
        soundList.add(new GameItem("monkey", R.raw.monkey));
        soundList.add(new GameItem("sheep", R.raw.sheep));
        soundList.add(new GameItem("chicken", R.raw.chicken));
        soundList.add(new GameItem("duck", R.raw.duck));
        soundList.add(new GameItem("elephant", R.raw.elephant));


    }

    /**
     * Tablica indeksów obrazów zawartych w zasobach gry.
     */
     int [] imageIds = {
            R.drawable.pig,
            R.drawable.horse,
            R.drawable.dog,
             R.drawable.cow,
             R.drawable.cat,
             R.drawable.chicken,
             R.drawable.donkey,
             R.drawable.duck,
             R.drawable.elephant,
             R.drawable.lion,
             R.drawable.monkey,
             R.drawable.sheep

    };

    /**
     * {@link AdultGame#setButtonBackgroundsRand()}
     */
    private void setButtonBackgroundsRand(){
        imgIdNumber = new ArrayList<Integer>();
        for(int i=0; i<imageIds.length;i++){
                imgIdNumber.add(imageIds[i]);

        }
        Random rnd = new Random();
        int where= rnd.nextInt(3);
        Collections.shuffle(imgIdNumber);
        for(int o=0;o<imageIds.length;o++){


           if(getResources().getResourceEntryName(imageIds[o]).equals(soundList.get(playedSoundIndex).name)){
                imgIdNumber.add(where,imageIds[o]);
               imgIdNumber.remove(imgIdNumber.lastIndexOf(imageIds[o]));
           }

        }



        Button btn1 = (Button) findViewById(R.id.animal1);
       Button btn2 = (Button) findViewById(R.id.animal2);
        Button btn3 = (Button) findViewById(R.id.animal3);

        btn1.setBackgroundResource(imgIdNumber.get(0));
        btn1.setOnClickListener(onClickListener);


        btn2.setBackgroundResource(imgIdNumber.get(1));
        btn2.setOnClickListener(onClickListener);
        btn3.setBackgroundResource(imgIdNumber.get(2));
        btn3.setOnClickListener(onClickListener);



    }

    /**
     * {@link AdultGame#checkIfCorrect(int, Button)}
     * @param id {@link AdultGame#checkIfCorrect(int, Button)#id}
     * @param backbutton{@link AdultGame#checkIfCorrect(int, Button)#backbutton}
     *
     */
    private void checkIfCorrect(int id, Button backbutton){
        getNameOfImg();


            if(imgNamesSelected.get(id).equals(soundList.get(playedSoundIndex).name)){


                sum=sum+points;
                Intent a=getIntent();
                SharedPreferences settings = getSharedPreferences("SUMA", 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putInt("Suma", sum);
                final MediaPlayer mp = MediaPlayer.create(this, R.raw.yay);

                editor.commit();
                try {
                    backbutton.setVisibility(View.VISIBLE);
                    backbutton.setBackgroundResource(R.drawable.good);

                    mp.start();
                    Thread.sleep(2000);


                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                mp.stop();
                finish();
                startActivity(a);




            }else{
                if(points>0){
                    points--;}
                else points=0;
                final MediaPlayer mp = MediaPlayer.create(this, R.raw.boo);
                try {
                    backbutton.setVisibility(View.VISIBLE);
                    backbutton.setBackgroundResource(R.drawable.bad);

                    mp.start();
                    Thread.sleep(2000);


                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                mp.stop();
                backbutton.setVisibility(View.INVISIBLE);



            }





    }

    /**
     *  {@link AdultGame#onClickListener}
     */



    private View.OnClickListener onClickListener = new View.OnClickListener() {
        int id;
        Button backButton;
        @Override
        public void onClick(final View v) {
            switch(v.getId()){
                case R.id.animal1:
                    backButton=(Button)findViewById(R.id.background1);

                    id=0;
                    checkIfCorrect(id,backButton);
                    break;
                case R.id.animal2:
                    backButton=(Button)findViewById(R.id.background2);
                    id=1;
                    checkIfCorrect(id,backButton);
                    break;
                case R.id.animal3:
                    backButton=(Button)findViewById(R.id.background3);
                    id=2;
                    checkIfCorrect(id,backButton);
                    break;
            }

        }
    };

    /**
     * {@link AdultGame#replay(View)}
     * @param view
     */
    public void replay(View view) {
    mp = MediaPlayer.create(this, this.soundList.get(playedSoundIndex).getResId());
    mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
        public void onCompletion(MediaPlayer mp) {

            mp.reset();
            mp.release();
            mp = null;
        }

    });
    try {
        mp.start();
        Thread.sleep(2000);
        mp.stop();

    } catch (InterruptedException e) {
        e.printStackTrace();
    }
}


    /**
     * {@link AdultGame#backToMenu(View)}
     * @param view {@link AdultGame#backToMenu(View)#view}
     * @throws InterruptedException
     */
    public  void backToMenu(View view) throws InterruptedException {



        String stringToSave =Integer.toString( sum)+"\n";
        writeToFile(stringToSave);
        Thread.sleep(2000);
        sum=0;
        SharedPreferences settings = getSharedPreferences("SUMA", 0);
        SharedPreferences.Editor editor = settings.edit();

        editor.putInt("Suma", 0);

        editor.commit();
        Intent intent = new Intent(getBaseContext(), MainActivity.class);
        finish();

        startActivity(intent);


    }

    /**{@link AdultGame#writeToFile(String)}
     *
     * @param data {@link AdultGame#writeToFile(String)#data}
     */
    private void writeToFile(String data) {
        FileOutputStream outputStream;

        try {

            FileInputStream fIn = openFileInput ( "SAVE_KG" ) ;
            InputStreamReader isr = new InputStreamReader ( fIn ) ;
            BufferedReader buff = new BufferedReader( isr ) ;

            String readString = buff.readLine ( ) ;



            outputStream = openFileOutput("SAVE_KG", Context.MODE_PRIVATE);
            readString+=" "+data;
            outputStream.write(readString.getBytes());
            outputStream.close();



            isr.close ( ) ;
            outputStream.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }



}
