/**
* Elisa Mamos IBM sem. V IwM ETI
* 155305
* 2016/17
*/
package com.example.elisa.krainadzwiekow;

import android.content.Context;

import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.ImageView;


/**
 * Created by Elisa on 2016-12-25.
 */

/**
 * Klasa odpowiadająca za możliwość przewijania grafik {@see img_resources} na ekranie.
 *  @author Elisa Mamos
 */

public class CustomSwipeAdaptor extends PagerAdapter {
    private int[] img_resources = {R.drawable.polecenie1, R.drawable.polecenie2,R.drawable.polecenie3,R.drawable.polecenie4,R.drawable.polecenie5,R.drawable.polecenie6,R.drawable.polecenie7};
    private Context ctx;
    private LayoutInflater layoutInflater;

    public int count;


    public CustomSwipeAdaptor(Context ctx){

        this.ctx=ctx;

    }
    @Override
    public int getCount() {
        this.count=img_resources.length;

        return img_resources.length ;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view== object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        layoutInflater=(LayoutInflater)ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View item_view= layoutInflater.inflate(R.layout.swipe_layout,container,false);

        ImageView imageView=(ImageView)item_view.findViewById(R.id.image_view);

        imageView.setImageResource(img_resources[position]);
        container.addView(item_view);
        return item_view;
    }
    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);

    }
}
