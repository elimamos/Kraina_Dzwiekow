/**
 * Elisa Mamos IBM sem. V IwM ETI
 * 155305
 * 2016/17
 */
package com.example.elisa.krainadzwiekow;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Klasa zajmująca się obsługą gry dla dorosłych, wraz z wszystkimi jej przypadkami.
 *
 * Rozgrywką nazywać będziemy pojedyncze wykonanie metod zawartych w tej klasie.
 * Na grę składa się dowolna liczba rozgrywek. Gra kończy się w momencie wywołania metody backToMenu(View);
 *
 * @author Elisa Mamos
 */
public class AdultGame extends AppCompatActivity {
    /**
     * Lista dźwięków odtwarzanych podczas gry.
     * Przechowywane w obiekcie typu GameItem - zapisywana jest nazwa oraz ID dźwięku w zasobach programu (R.drawable).
    */
    private List<GameItem> soundList = new ArrayList<GameItem>();
    /**
     * Lista obrazów wykorzytywanych podczas gry. Obrazy dobrane są w pary pod względem podobieństwa nazw.
     * Przechowywane w obiekcie typu PicturePair - zapisywane są nazwy oraz ID obrazów w zasobach programu (R.raw).
     */
    private List<PicturePair> imagePairsList = new ArrayList<PicturePair>();
    /**
     * Lista ID obrazów wykorzytywanych podczas jednej rozgrywki.
     */
    ArrayList<Integer> selectedIMG = new ArrayList<Integer>();
    /**
     * Lista nazw obrazów wykorzytywanych podczas jednej rozgrywki.
     */
    List<String> imgNamesList = new ArrayList<>();
    /**
     * Generator liczb losowych.
     */
    private Random randomGenerator;
    /**
     * Odtwarzacz multimedialny.
     */
    MediaPlayer mp;
    /**
     * ID odtworzonego w danej rozgrywce dźwięku.
     */
    int playedSoundIndex;
    /**
     * Ilość  punktów do zdobycia podczas jendej rozgrywki.
     */
    int points = 2;
    /**
     * Suma  punktów zdobytych podczas rozgrywek.
     */
    int sum;
    /**
     * Klasa zajmująca się załadowaniem interfejsu gry, przypisaniem do zmiennej "sum" sumy punktów uzyskanej w poprzedniej rozgrywce,
     *załadowaniem dźwięków do listy obiektów typu GameItem, załadowaniem grafik do listy obiektów typu PicturePair, wylosowaniem
     * losowego indeksu dźwięku,który zostanie odtworzony, wylosowaniem i ustawieniem tła przycisków. Odtworzony zostaje też dźwięk
     * w celu rozpoczęcia rozgrywki. Dzieje się to z wymuszonym opóźnieniem, gdyż aplikacja potrzebuje czasu do pełnego załadowania interfejsu.
     * @param savedInstanceState Przechowuje parametry z poprzednich uruchomień metody.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adult_game);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        SharedPreferences settings = getSharedPreferences("SUMA", 0);
        sum = settings.getInt("Suma", 0);
        Button bckgrnd1 = (Button) findViewById(R.id.background1);
        Button bckgrnd2 = (Button) findViewById(R.id.background2);
        Button bckgrnd3 = (Button) findViewById(R.id.background3);
        bckgrnd1.setVisibility(View.INVISIBLE);
        bckgrnd2.setVisibility(View.INVISIBLE);
        bckgrnd3.setVisibility(View.INVISIBLE);
        loadSounds();
        loadImages();
        getSoundId();
        setButtonBackgroundsRand();
        TextView txt = (TextView) findViewById(R.id.sum);

        txt.setText( Integer.toString(sum));
        Runnable task = new Runnable() {
            public void run() {
                playSound();

            }
        };

        Handler handler = new Handler();
        handler.postDelayed(task, 1000);

    }

    /**
     * Dodaje obrazy do listy obiektów typu Picture Pair.
     * {@see PicturePair.class}
     *
     */
    private void loadImages() {
        imagePairsList.add(new PicturePair(R.drawable.dama, "dama", R.drawable.lama, "lama"));
        imagePairsList.add(new PicturePair(R.drawable.tama, "tama", R.drawable.lama, "lama"));
        imagePairsList.add(new PicturePair(R.drawable.gora, "gora", R.drawable.kura, "kura"));
        imagePairsList.add(new PicturePair(R.drawable.korki, "korki", R.drawable.worki, "worki"));
        imagePairsList.add(new PicturePair(R.drawable.lody, "lody", R.drawable.loty, "loty"));
        imagePairsList.add(new PicturePair(R.drawable.paczka, "paczka", R.drawable.taczka, "taczka"));

    }

    /**
     * Dodaje dźwięki do listy obiektów typu Game Item (zapisuje ID dźwieku  z jego nazwą).
     * {@see GameItem.class}
     */

    private void loadSounds() {
        soundList.add(new GameItem("loty", R.raw.loty));
        soundList.add(new GameItem("lody", R.raw.lody));
        soundList.add(new GameItem("dama", R.raw.dama));
        soundList.add(new GameItem("tama", R.raw.tama));
        soundList.add(new GameItem("lama", R.raw.lama));
        soundList.add(new GameItem("gora", R.raw.gora));
        soundList.add(new GameItem("kura", R.raw.kura));
        soundList.add(new GameItem("korki", R.raw.korki));
        soundList.add(new GameItem("worki", R.raw.worki));
        soundList.add(new GameItem("paczka", R.raw.paczka));
        soundList.add(new GameItem("taczka", R.raw.taczka));
    }

    /**
     *   Losuje indeks z listy dźwięków ( który ma być odtworzony).
     *
     */
      private void getSoundId() {
        randomGenerator = new Random();
        playedSoundIndex = randomGenerator.nextInt(soundList.size());


    }

    /**
     * Ustawia tła przycisków, tak by dwa były z obiektu PicturePair, a ostatni losowy.
     */

    private void setButtonBackgroundsRand() {
        String soundName = soundList.get(playedSoundIndex).name;
        int chosenPairId = -1;
        //szuka pary obrazów, które odpowiadają nazwie dźwięku i dodaje je do listy wybranych obrazów.
        for (int a = 0; a < imagePairsList.size(); a++) {
            if (soundName.equals(imagePairsList.get(a).name1) || soundName.equals(imagePairsList.get(a).name2)) {

                selectedIMG.add(imagePairsList.get(a).idres1);

                selectedIMG.add(imagePairsList.get(a).idres2);

                chosenPairId = a;
                break;
            }
        }

        int random = randomGenerator.nextInt(imagePairsList.size());

        // Jeśli id obrazu równe jest z id wybranego obrazu =nowa zmienna losowa.
        while (random == chosenPairId) {
            random = randomGenerator.nextInt(imagePairsList.size());

        }
        selectedIMG.add(imagePairsList.get(random).idres1);



        Collections.shuffle(selectedIMG);
        for (int o = 0; o < selectedIMG.size(); o++) {
            for (int b = 0; b < imagePairsList.size(); b++) {
                if (selectedIMG.get(o) == imagePairsList.get(b).idres1) {
                    imgNamesList.add(imagePairsList.get(b).name1);
                    break;

                } else if (selectedIMG.get(o) == imagePairsList.get(b).idres2) {
                    imgNamesList.add(imagePairsList.get(b).name2);
                    break;
                }
            }
        }



        Button btn1 = (Button) findViewById(R.id.animal1);
        Button btn2 = (Button) findViewById(R.id.animal2);
        Button btn3 = (Button) findViewById(R.id.animal3);

        btn1.setBackgroundResource(selectedIMG.get(0));
        btn1.setOnClickListener(onClickListener);


        btn2.setBackgroundResource(selectedIMG.get(1));
        btn2.setOnClickListener(onClickListener);
        btn3.setBackgroundResource(selectedIMG.get(2));
        btn3.setOnClickListener(onClickListener);


    }

    /**
     * Sprawdza, który z przycisków został wciśnięty, a następnie sprawdza czy został wciśnięty poprawny przycisk.
     * {@see checkIfCorrect}
     */
    private View.OnClickListener onClickListener = new View.OnClickListener() {
        int id;
        Button backButton;

        @Override
        public void onClick(final View v) {
            switch (v.getId()) {
                case R.id.animal1:
                    backButton = (Button) findViewById(R.id.background1);

                    id = 0;
                    checkIfCorrect(id, backButton);
                    break;
                case R.id.animal2:
                    backButton = (Button) findViewById(R.id.background2);
                    id = 1;
                    checkIfCorrect(id, backButton);
                    break;
                case R.id.animal3:
                    backButton = (Button) findViewById(R.id.background3);
                    id = 2;
                    checkIfCorrect(id, backButton);
                    break;
            }

        }
    };

    /**
     * Odtwarza dźwięk znajdujący się pod zapisanym wcześniej indeksem w zasobach programu.
     * {@see playedSoundIndex}
     */
    public void playSound() {


        mp = MediaPlayer.create(this, this.soundList.get(playedSoundIndex).getResId());
        mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            public void onCompletion(MediaPlayer mp) {

                mp.reset();
                mp.release();
                mp = null;
            }

        });
        try {
            mp.start();
            Thread.sleep(2000);
            mp.stop();

        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    /**
     * Metoda powodująca zamknięcie bierzącego okna i powrót do menu głównego gry.
     * Przed powrotem zapiswany jest do pilku uzyskany wynik, a suma zerowana i przesyłana, tak by przy kolejnym uruchomieniu gry suma wynosiła 0.
     *
     * @param view the view
     */
    public void backToMenu(View view) {

        Intent intent = new Intent(getBaseContext(), MainActivity.class);


         String stringToSave =Integer.toString( sum);
         writeToFile(stringToSave);
        sum=0;
        SharedPreferences settings = getSharedPreferences("SUMA", 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putInt("Suma", 0);

        editor.commit();
        finish();

        startActivity(intent);


    }

    /**
     * Metoda sprawdzająca poprawność wcisniętego przycisku. W zależności od wyniku (poprawny/niepoprawny) odtwarzany jest odpowiedni dźwięk
     * i grafika zostaje podświetlona w odpowiedni sposób. (Przycisk znajdujący się za przyciskiem z grafiką zmienia swój stan na VISIBLE i jako tło
     * ustawiana zostaje odpowiednia grafika).
     * Gdy odpowiedź była poprawna gracz dostaje punkty - za pierwszym razem 2 {@see points}, a za każdą kolejną próbę odjęty zostaje mu jeden punkt.
     * Zdobyte podczas rozgrywki punkty dodawane są do sumy.
     * @param id ID przycisku, który został wciśnięty, odpowiadający indeksowi w liscie nazw grafik ( nazwa grafiki, która stanowi tło danego przycisku).
     * @param backbutton Przycisk znajdujący się w tle przycisku z grafiką, odpowiadając za wyświetlenie informacji o poprawności wyboru.
     */
    private void checkIfCorrect(int id, Button backbutton) {


        if (imgNamesList.get(id).equals(soundList.get(playedSoundIndex).name)) {


            sum = sum + points;
            Intent a = getIntent();
            SharedPreferences settings = getSharedPreferences("SUMA", 0);
            SharedPreferences.Editor editor = settings.edit();
            editor.putInt("Suma", sum);
            final MediaPlayer mp = MediaPlayer.create(this, R.raw.yay);

            editor.commit();
            try {
                backbutton.setVisibility(View.VISIBLE);
                backbutton.setBackgroundResource(R.drawable.good);

                mp.start();
                Thread.sleep(2000);


            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            mp.stop();
            finish();
            startActivity(a);


        } else {
            if (points > 0) {
                points--;
            } else points = 0;
            final MediaPlayer mp = MediaPlayer.create(this, R.raw.boo);
            try {
                backbutton.setVisibility(View.VISIBLE);
                backbutton.setBackgroundResource(R.drawable.bad);

                mp.start();
                Thread.sleep(2000);


            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            mp.stop();
            backbutton.setVisibility(View.INVISIBLE);


        }

    }
/**
 * Zapisywanie do pliku wyniku gry.
 * @param data Suma punktów do zapisania w pliku.
 */

    private void writeToFile(String data) {
        FileOutputStream outputStream;

        try {

            FileInputStream fIn = openFileInput ( "SAVE_AG" ) ;
            InputStreamReader isr = new InputStreamReader ( fIn ) ;
            BufferedReader buff = new BufferedReader( isr ) ;

            String readString = buff.readLine ( ) ;



            outputStream = openFileOutput("SAVE_AG", Context.MODE_PRIVATE);
            readString+=" "+data;
            outputStream.write(readString.getBytes());
            outputStream.close();



            isr.close ( ) ;
            outputStream.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * Ponowne odtworzenie dźwięku.
     *
     * @param view the view
     */
    public void replay(View view) {
        mp = MediaPlayer.create(this, this.soundList.get(playedSoundIndex).getResId());
        mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            public void onCompletion(MediaPlayer mp) {

                mp.reset();
                mp.release();
                mp = null;
            }

        });
        try {
            mp.start();
            Thread.sleep(2000);
            mp.stop();

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
