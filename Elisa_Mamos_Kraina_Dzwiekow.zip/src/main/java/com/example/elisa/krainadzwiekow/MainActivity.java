/**
 * Elisa Mamos IBM sem. V IwM ETI
 * 155305
 * 2016/17
 */
package com.example.elisa.krainadzwiekow;

import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.support.v7.app.AppCompatDelegate;
import android.view.View;

/**
 * Głowna klasa gry. Stanowi menu główne gry.
 * @author Elisa Mamos
 */
public class MainActivity extends AppCompatActivity {
    static {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
    }

    /**
     * Metoda ładująca interfejs graficzny.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.activity_main);



    }

    /**
     * Metoda otwierająca okno z grą dla dzieci.
     * @see KidsGame
     * @param view
     */
    public void openKidsGame(View view){
        Intent intent = new Intent(MainActivity.this, KidsGame.class);
        startActivity(intent);
    }
    /**
     * Metoda otwierająca okno z infomacjami o grze.
     * @see Info
     * @param view
     */
    public void openInfo(View view){
        Intent intent = new Intent(MainActivity.this, Info.class);
        startActivity(intent);


    }
    /**
     * Metoda otwierająca okno z grą dla dorosłych.
     * @see AdultGame
     * @param view
     */
    public void openAdultGame(View view){
        Intent intent = new Intent(MainActivity.this, AdultGame.class);
        startActivity(intent);
    }
    /**
     * Metoda otwierająca okno ze statystykami.
     * @see Stats
     * @param view
     */
    public void openStatistics(View view){
        Intent intent = new Intent(MainActivity.this,Stats.class);
        startActivity(intent);
    }

}
