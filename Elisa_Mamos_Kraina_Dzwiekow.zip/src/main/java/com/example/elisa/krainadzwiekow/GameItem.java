/**
 * Elisa Mamos IBM sem. V IwM ETI
 * 155305
 * 2016/17
 */
package com.example.elisa.krainadzwiekow;

/**
 * Created by Elisa on 2016-11-19.
 */

/**
 * * Klasa przechowująca dane dźwięków (nazwę i ID w zasobach).
 *  @author Elisa Mamos
 */
public class GameItem {
    public String name;
    private int resId;

    public int getResId() {
        return resId;
    }

    public String getName() {
        return name;
    }

    GameItem(String name, int resId){
        this.resId=resId;
        this.name=name;
    }
}