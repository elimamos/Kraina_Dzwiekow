/**
 * Elisa Mamos IBM sem. V IwM ETI
 * 155305
 * 2016/17
 */
package com.example.elisa.krainadzwiekow;

/**
 * Klasa przechowująca dane obrazów sparowanych pod względem podobieństwa nazw.
 *  @author Elisa Mamos
 *
 */

public class PicturePair {
    public int idres1;
    public  String name1;
    public int idres2;
    public String name2;


    /**
     * Klasa przypisująca @param  do zmiennych klasy PicturePair.
     * @param id1 ID w zasobach pierwszego obrazu z pary
     * @param name1 Nazwa pierwszego obrazka z pary odpowiadająca jego zawartości.
     * @param id2 ID w zasobach drugiego obrazu z pary
     * @param name2 Nazwa drugiego obrazka z pary odpowiadająca jego zawartości.
     */
    PicturePair(int id1, String name1, int id2, String name2){
        this.idres1=id1;
        this.name1=name1;
        this.idres2=id2;
        this.name2=name2;
    }
}
