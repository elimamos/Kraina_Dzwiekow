/**
 * Elisa Mamos IBM sem. V IwM ETI
 * 155305
 * 2016/17
 */
package com.example.elisa.krainadzwiekow;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.DataPointInterface;
import com.jjoe64.graphview.series.LineGraphSeries;
import com.jjoe64.graphview.series.OnDataPointTapListener;
import com.jjoe64.graphview.series.Series;

import java.io.BufferedReader;
import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Klasa zajmująca się wyswietlaniem statystyk wyników gier.
 * @author Elisa Mamos
 */
public class Stats extends AppCompatActivity {
    /**
     * Obiekt umożliwiający wyświetlanie wykresu liniowego.
     */
    GraphView graph;

    /**
     * Metoda zajmująca się ładowaniem interfesu oraz wykresu (ustawiania jego właściwości i wyświetlanych wartości).
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);
        String splitedKG[] = readSavedData("SAVE_KG").split(" ");
        String adultSplited[] = readSavedData("SAVE_AG").split(" ");
        TextView sumkg=(TextView)findViewById(R.id.sumkg);
        sumkg.setText(sum(splitedKG));
        TextView sumag=(TextView)findViewById(R.id.sumag);
        sumag.setText(sum(adultSplited));

        graph = (GraphView) findViewById(R.id.graph);
        graph.getLegendRenderer().setVisible(true);
        graph.getLegendRenderer().setFixedPosition(0,0);
        graph.getViewport().setYAxisBoundsManual(true);
        graph.getViewport().setMinY(0);
        graph.getViewport().setMaxY(20);
        graph.getViewport().setXAxisBoundsManual(true);
        graph.getViewport().setMinX(1);
        graph.getViewport().setMaxX(20);
        graph.getViewport().setScalable(true);
        graph.getViewport().setScalableY(true);
        graph.getViewport().setBackgroundColor(Color.WHITE);





        LineGraphSeries<DataPoint> series = new LineGraphSeries<>();
        series.setColor(Color.MAGENTA);
        series.setDrawDataPoints(true);
        series.setDataPointsRadius(5);
        series.setTitle("Kids Game");




        for (int i=1;i<splitedKG.length;i++){
            int y=Integer.parseInt(splitedKG[i].trim());
            series.appendData(new DataPoint(i,y),true,1000);
        }

        GridLabelRenderer glr = graph.getGridLabelRenderer();
        glr.setPadding(32);

        LineGraphSeries<DataPoint> series2 = new LineGraphSeries<>();
        series2.setColor(Color.BLUE);
        series2.setDrawDataPoints(true);
        series2.setDataPointsRadius(5);
        series2.setTitle("Adult Game");

        for (int i=1;i<adultSplited.length;i++){
            int y=Integer.parseInt(adultSplited[i].trim());
            series2.appendData(new DataPoint(i,y),true,1000);
        }
        graph.addSeries(series);
        graph.addSeries(series2);
        series.setOnDataPointTapListener(new OnDataPointTapListener() {


            @Override
            public void onTap(Series series, DataPointInterface dataPoint) {
                Toast.makeText(Stats.this, series.getTitle()+" Otrzymano "+(int)dataPoint.getY()+" pkt.", Toast.LENGTH_SHORT).show();

            }


        });
        series2.setOnDataPointTapListener(new OnDataPointTapListener() {


            @Override
            public void onTap(Series series, DataPointInterface dataPoint) {
                Toast.makeText(Stats.this, series.getTitle()+" Otrzymano "+(int)dataPoint.getY()+" pkt.", Toast.LENGTH_SHORT).show();

            }


        });





    }

   public String readSavedData (String filename ) {
       String readString="";

        try {
            FileInputStream fIn = openFileInput ( filename ) ;
            InputStreamReader isr = new InputStreamReader ( fIn ) ;
            BufferedReader buff = new BufferedReader( isr ) ;

            readString = buff.readLine ( );
            readString.trim();


            isr.close ( ) ;
        } catch ( IOException ioe ) {
            ioe.printStackTrace ( ) ;

        }
       return readString ;
    }

    /**
     * Metoda wyświetlająca okno wyboru, czy dane mają zostać usunięte z podanego pliku.
     * @param fileName Nazwa pliku, który ma zostać wyczyszczony.
     *
     */
    public void clickClear(final String fileName){
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setMessage("Czy na pewno chcesz usunąć wszystkie dotychczasowe wyniki?");
        builder1.setCancelable(true);



        builder1.setPositiveButton(
                "Tak",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        dialog.cancel();
                       clearTheFile(fileName);
                        Intent intent = new Intent(getBaseContext(), Stats.class);
                        finish();

                        startActivity(intent);

                    }
                });

        builder1.setNegativeButton(
                "Nie",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
        Button p =alert11.getButton(DialogInterface.BUTTON_POSITIVE);
        Button n =alert11.getButton(DialogInterface.BUTTON_NEGATIVE);
        p.setTextColor(Color.BLACK);
        n.setTextColor(Color.BLACK);


    }

    /**
     * Metoda zajmująca się czyszczeniem pliku z zapisanych wcześniej wyników.
     * @param fileName Nazwa pliku, który ma zostać wyczyszczony.
     */
    public void clearTheFile(String fileName) {
        FileOutputStream outputStream;
        try {
            outputStream = openFileOutput(fileName, Context.MODE_PRIVATE);
            outputStream.write("0".getBytes());
            outputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
    public void kgClear(View view){
        clickClear("SAVE_KG");

    }
    public void agClear(View view){
        clickClear("SAVE_AG");

    }

    /**
     * {@link AdultGame#backToMenu(View)}
     * @param view
     */
    public void backToMenu(View view) {

        Intent intent = new Intent(getBaseContext(), MainActivity.class);

        finish();

        startActivity(intent);


    }

    /**
     * Metoda sumująca dotychczas otrzymane punkty z danej gry.
     * @param array Tablica wyników z danej gry.
     * @return Zwraca sumę w postaci String.
     */
    public String sum(String[]array) {
        int suma=0;
        for (int t = 0; t < array.length; t++) {
                suma=suma+Integer.parseInt(array[t].trim());
        }
        return Integer.toString(suma);
    }



}
