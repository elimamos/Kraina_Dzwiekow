/**
 * Elisa Mamos IBM sem. V IwM ETI
 * 155305
 * 2016/17
 */
package com.example.elisa.krainadzwiekow;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatDelegate;

import android.view.View;

/**
 * Klasa odpowiadajaca za wyświetlanie informacji na temat przebiegu gry oraz jej twórców.
 * @author Elisa Mamos
 */
public class Info extends AppCompatActivity {
    /**
     *  Obiekt umożliwiający podgląd stron w formie przewijalnej.
     */
    ViewPager viewPager;
    CustomSwipeAdaptor adaptor;
    public Info(){}

    /**
     * Metoda mająca na celu załadowanie interfejsu i wyświetlenie grafik z informacjami o grze.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        viewPager=(ViewPager)findViewById(R.id.view_pager);
        adaptor=new CustomSwipeAdaptor(this);
        viewPager.setAdapter(adaptor);





    }
/**
 *  {@link AdultGame#backToMenu(View)}
 */
    public  void backToMenu(View view){

        Intent intent = new Intent(getBaseContext(), MainActivity.class);
        startActivity(intent);


    }


}
